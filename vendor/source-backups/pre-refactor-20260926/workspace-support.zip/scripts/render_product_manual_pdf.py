from __future__ import annotations

import html
import hashlib
import json
import re
import subprocess
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate,
    Frame,
    Image as RLImage,
    PageBreak,
    PageTemplate,
    Paragraph,
    Spacer,
)
from PIL import Image as PILImage


ROOT = Path(__file__).resolve().parents[1]
TEX_PATH = ROOT / "docs" / "产品说明书.tex"
PDF_PATH = ROOT / "output" / "pdf" / "新型电力系统智能地球时序模拟与碳电协同分析平台产品说明书_修订版.pdf"
FORMULA_DIR = ROOT / "tmp" / "pdfs" / "formula-images"
ANACONDA_PYTHON = Path(r"C:\Users\53472\anaconda3\python.exe")


def register_font(name: str, candidates: list[str]) -> str:
    for candidate in candidates:
        path = Path(candidate)
        if path.exists():
            try:
                pdfmetrics.registerFont(TTFont(name, str(path)))
                return name
            except Exception:
                continue
    return "Helvetica"


BODY_FONT = register_font(
    "ManualBody",
    [
        r"C:\Windows\Fonts\NotoSerifSC-VF.ttf",
        r"C:\Windows\Fonts\simfang.ttf",
        r"C:\Windows\Fonts\simkai.ttf",
    ],
)
BOLD_FONT = register_font(
    "ManualBold",
    [
        r"C:\Windows\Fonts\simhei.ttf",
        r"C:\Windows\Fonts\NotoSansSC-VF.ttf",
        r"C:\Windows\Fonts\simsunb.ttf",
    ],
)
pdfmetrics.registerFontFamily(
    BODY_FONT,
    normal=BODY_FONT,
    bold=BOLD_FONT,
    italic=BODY_FONT,
    boldItalic=BOLD_FONT,
)


def latex_to_text(value: str) -> str:
    value = value.strip()
    value = re.sub(r"\\textbf\{([^{}]*)\}", r"[[B]]\1[[/B]]", value)
    value = value.replace(r"$C$", "C")
    value = value.replace(r"$P_t$", "P_t")
    value = value.replace(r"$t$", "t")
    value = value.replace(r"$v_t$", "v_t")
    value = value.replace(r"$f(v_t)$", "f(v_t)")
    value = value.replace(r"$G_t$", "G_t")
    value = value.replace(r"$G_{std}$", "G_std")
    value = value.replace(r"$T_t$", "T_t")
    value = value.replace(r"$T_{std}$", "T_std")
    value = value.replace(r"$\gamma$", "gamma")
    value = value.replace(r"$X_i$", "X_i")
    value = value.replace(r"$w_i$", "w_i")
    value = value.replace(r"$CF_t$", "CF_t")
    value = value.replace(r"$P_{i,r,t}$", "P_{i,r,t}")
    value = value.replace(r"$E_{r,t}$", "E_{r,t}")
    value = value.replace(r"$r$", "r")
    value = value.replace(r"$i$", "i")
    value = value.replace(r"$EF_i$", "EF_i")
    value = re.sub(r"\\url\{([^}]*)\}", r"\1", value)
    value = re.sub(r"\\texttt\{([^}]*)\}", r"\1", value)
    value = value.replace(r"\textbackslash", "\\")
    value = re.sub(r"\\mathrm\{([^}]*)\}", r"\1", value)
    value = value.replace(r"\_", "_")
    value = value.replace(r"\%", "%")
    value = value.replace(r"\&", "&")
    value = value.replace(r"\\", "")
    return value.strip()


def read_tex_blocks() -> list[tuple[str, str]]:
    raw = TEX_PATH.read_text(encoding="utf-8")
    body = raw.split(r"\begin{document}", 1)[1].split(r"\end{document}", 1)[0]
    body = re.sub(r"\\maketitle|\\thispagestyle\{empty\}|\\vspace\{[^}]*\}", "", body)
    blocks: list[tuple[str, str]] = []
    in_items = False
    in_formula = False
    formula_lines: list[str] = []

    for line in body.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("%"):
            continue
        if stripped == r"\[":
            in_formula = True
            formula_lines = []
            continue
        if stripped == r"\]":
            blocks.append(("formula", " ".join(formula_lines).strip()))
            in_formula = False
            formula_lines = []
            continue
        if in_formula:
            formula_lines.append(stripped)
            continue
        section = re.match(r"\\section\{(.+)\}", stripped)
        if section:
            blocks.append(("section", latex_to_text(section.group(1))))
            continue
        subsection = re.match(r"\\subsection\{(.+)\}", stripped)
        if subsection:
            blocks.append(("subsection", latex_to_text(subsection.group(1))))
            continue
        if stripped == r"\begin{itemize}":
            in_items = True
            continue
        if stripped == r"\end{itemize}":
            in_items = False
            continue
        item = re.match(r"\\item\s+(.+)", stripped)
        if item:
            blocks.append(("item", latex_to_text(item.group(1))))
            continue
        if in_items:
            blocks.append(("item", latex_to_text(stripped)))
        elif not stripped.startswith("\\") or stripped.startswith(r"\textbf"):
            blocks.append(("paragraph", latex_to_text(stripped)))

    return blocks


def formula_image_path(formula: str) -> Path:
    FORMULA_DIR.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha1(formula.encode("utf-8")).hexdigest()[:16]
    return FORMULA_DIR / f"{key}.png"


def render_formula_jobs(jobs: list[tuple[str, Path]]) -> bool:
    if not jobs:
        return True

    render_code = r"""
import sys
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

jobs = json.loads(sys.argv[1])
for formula, out in jobs:
    fig = plt.figure(figsize=(8.0, 0.7))
    fig.patch.set_alpha(0)
    ax = fig.add_axes([0, 0, 1, 1])
    ax.axis("off")
    ax.text(0.5, 0.5, "$" + formula + "$", ha="center", va="center", fontsize=17, color="#111111")
    fig.savefig(out, dpi=220, transparent=True, bbox_inches="tight", pad_inches=0.04)
    plt.close(fig)
"""
    payload = json.dumps([(formula, str(path)) for formula, path in jobs], ensure_ascii=False)
    executables = [str(ANACONDA_PYTHON), "python", "py"] if ANACONDA_PYTHON.exists() else ["python", "py"]
    for executable in executables:
        try:
            subprocess.run(
                [executable, "-c", render_code, payload],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=120,
            )
            return True
        except Exception:
            continue
    return False


def ensure_formula_images(formulas: list[str]) -> None:
    jobs: list[tuple[str, Path]] = []
    for formula in formulas:
        image_path = formula_image_path(formula)
        if not image_path.exists():
            jobs.append((formula, image_path))
    render_formula_jobs(jobs)


def formula_flowable(formula: str, max_width: float):
    image_path = formula_image_path(formula)
    if not image_path.exists():
        render_formula_jobs([(formula, image_path)])
    if not image_path.exists():
        fallback = formula.replace(r"\cdot", "·").replace(r"\sum", "Σ")
        return Paragraph(html.escape(fallback), ParagraphStyle(
            "FormulaFallback",
            fontName=BODY_FONT,
            fontSize=10.5,
            leading=16,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#111111"),
            wordWrap="CJK",
        ))

    with PILImage.open(image_path) as image:
        pixel_width, pixel_height = image.size
    width = pixel_width / 220 * 72
    height = pixel_height / 220 * 72
    if width > max_width:
        scale = max_width / width
        width *= scale
        height *= scale
    return RLImage(str(image_path), width=width, height=height, hAlign="CENTER")


class ManualDoc(BaseDocTemplate):
    def __init__(self, filename: str):
        super().__init__(
            filename,
            pagesize=A4,
            leftMargin=2.65 * cm,
            rightMargin=2.65 * cm,
            topMargin=2.55 * cm,
            bottomMargin=2.3 * cm,
        )
        frame = Frame(
            self.leftMargin,
            self.bottomMargin,
            self.width,
            self.height,
            leftPadding=0,
            rightPadding=0,
            topPadding=0,
            bottomPadding=0,
        )
        self.addPageTemplates([PageTemplate(id="manual", frames=[frame], onPage=draw_header_footer)])


def draw_header_footer(canvas, doc):
    canvas.saveState()
    width, height = A4
    header_y = height - 1.75 * cm
    canvas.setStrokeColor(colors.HexColor("#1f4e79"))
    canvas.setLineWidth(0.45)
    canvas.line(doc.leftMargin, header_y - 0.25 * cm, width - doc.rightMargin, header_y - 0.25 * cm)
    canvas.setFont(BODY_FONT, 8.5)
    canvas.setFillColor(colors.HexColor("#4a4a4a"))
    canvas.drawString(doc.leftMargin, header_y, "新型电力系统智能地球时序模拟与碳电协同分析平台")
    canvas.drawRightString(width - doc.rightMargin, header_y, "产品说明书")
    canvas.setFont(BODY_FONT, 9)
    canvas.drawCentredString(width / 2, 1.35 * cm, f"- {doc.page} -")
    canvas.restoreState()


def escaped(text: str) -> str:
    text = html.escape(text, quote=False).replace("\n", "<br/>")
    return text.replace("[[B]]", "<b>").replace("[[/B]]", "</b>")


def build_pdf() -> None:
    PDF_PATH.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "TitleCn",
        parent=styles["Title"],
        fontName=BOLD_FONT,
        fontSize=22,
        leading=32,
        alignment=TA_CENTER,
        textColor=colors.HexColor("#111111"),
        spaceAfter=0.7 * cm,
        wordWrap="CJK",
    )
    section = ParagraphStyle(
        "SectionCn",
        parent=styles["Heading1"],
        fontName=BOLD_FONT,
        fontSize=17,
        leading=24,
        alignment=TA_CENTER,
        textColor=colors.HexColor("#111111"),
        spaceBefore=0.45 * cm,
        spaceAfter=0.35 * cm,
        wordWrap="CJK",
    )
    subsection = ParagraphStyle(
        "SubsectionCn",
        parent=styles["Heading2"],
        fontName=BOLD_FONT,
        fontSize=13.5,
        leading=21,
        alignment=TA_LEFT,
        textColor=colors.HexColor("#111111"),
        spaceBefore=0.35 * cm,
        spaceAfter=0.18 * cm,
        wordWrap="CJK",
    )
    body = ParagraphStyle(
        "BodyCn",
        parent=styles["BodyText"],
        fontName=BODY_FONT,
        fontSize=11.2,
        leading=20.2,
        firstLineIndent=22,
        alignment=TA_LEFT,
        textColor=colors.HexColor("#222222"),
        spaceAfter=0.23 * cm,
        wordWrap="CJK",
    )
    item = ParagraphStyle(
        "ItemCn",
        parent=body,
        firstLineIndent=0,
        leftIndent=17,
        bulletIndent=3,
        spaceAfter=0.16 * cm,
    )

    story = [
        Spacer(1, 1.1 * cm),
        Paragraph("新型电力系统智能地球时序模拟与碳电协同分析平台<br/>产品说明书", title),
        Spacer(1, 0.8 * cm),
        PageBreak(),
    ]

    doc = ManualDoc(str(PDF_PATH))
    blocks = read_tex_blocks()
    ensure_formula_images([text for kind, text in blocks if kind == "formula"])

    section_index = 0
    for kind, text in blocks:
        if kind == "section":
            section_index += 1
            story.append(Paragraph(f"{section_index}、{escaped(text)}", section))
        elif kind == "subsection":
            story.append(Paragraph(escaped(text), subsection))
        elif kind == "paragraph":
            story.append(Paragraph(escaped(text), body))
        elif kind == "formula":
            story.append(Spacer(1, 0.04 * cm))
            story.append(formula_flowable(text, doc.width))
            story.append(Spacer(1, 0.08 * cm))
        elif kind == "item":
            story.append(Paragraph(escaped(text), item, bulletText="•"))

    doc.build(story)


if __name__ == "__main__":
    build_pdf()
    print(PDF_PATH)
