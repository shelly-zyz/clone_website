@echo off
node "%~dp0ai-website-cloner-template\scripts\start-local-voice.mjs"
if errorlevel 1 pause
