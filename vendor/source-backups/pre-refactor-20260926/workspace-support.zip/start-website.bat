@echo off
setlocal

set "APP_DIR=%~dp0ai-website-cloner-template"
set "PORT=3000"
set "APP_URL=http://127.0.0.1:%PORT%"

title Start Website
echo Starting website launcher...
echo Project: %APP_DIR%
echo URL: %APP_URL%
echo.

if not exist "%APP_DIR%\package.json" (
  echo ERROR: package.json was not found in:
  echo %APP_DIR%
  echo.
  pause
  exit /b 1
)

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js was not found.
  echo Please install Node.js 24 or newer, then run this file again.
  echo https://nodejs.org/
  echo.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found.
  echo Please install Node.js 24 or newer, then run this file again.
  echo https://nodejs.org/
  echo.
  pause
  exit /b 1
)

cd /d "%APP_DIR%"

if not exist "node_modules" (
  echo Dependencies were not found. Installing now...
  call npm install
  if errorlevel 1 (
    echo.
    echo ERROR: npm install failed.
    pause
    exit /b 1
  )
  echo.
)

echo.
echo Checking website and Xiaoyun services...
node scripts/start-local-voice.mjs --no-open
if errorlevel 1 (
  echo.
  echo ERROR: The website or Xiaoyun service failed to start.
  echo Check the logs in %APP_DIR%\.xiaoyun\
  pause
  exit /b 1
)

echo Opening %APP_URL% ...
start "" "%APP_URL%"
echo.
echo This launcher will close automatically.
timeout /t 2 /nobreak >nul
